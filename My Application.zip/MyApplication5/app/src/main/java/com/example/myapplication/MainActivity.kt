package com.example.myapplication



import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myapplication.databinding.ActivityMainBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries
import java.text.SimpleDateFormat
import java.time.Period
import java.util.*


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {



       // val graphView: GraphView = findViewById(R.id.graph)


      //  val series: LineGraphSeries<DataPoint> = LineGraphSeries(arrayOf(
         //   DataPoint(0.0, 1.0),
         //   DataPoint(1.0, 5.0),
          //  DataPoint(2.0, 3.0),
         //   DataPoint(3.0, 2.0),
         //   DataPoint(4.0, 6.0)
       // ))



        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)



    }

    fun onClick(view: View?) {


       // val graphView: GraphView = findViewById(R.id.graph)


        //  val series: LineGraphSeries<DataPoint> = LineGraphSeries(arrayOf(
         // DataPoint(0.0, 1.0),
         //  DataPoint(1.0, 5.0),
      //  DataPoint(2.0, 3.0),
       //   DataPoint(3.0, 2.0),
        //   DataPoint(4.0, 6.0)
      //  ))




        val db = baseContext.openOrCreateDatabase("app.db", MODE_PRIVATE, null)

        val editView :TextView= findViewById<TextView>(R.id.editTextTextPersonName)

        val a=editView.text.toString().toInt()
     //  val a=editView.text.toString().toInt()
     //   val b =editView.text.toString().toInt()


        val datab= Database(db)
        datab.createDB(this,"measures")

        val currentDate = Date()
        val dateFormatter = SimpleDateFormat("dd.MM.yyyy")
        val dateString = dateFormatter.format(currentDate)
        val sqlstring4 = "INSERT OR IGNORE INTO measures (date,weight) VALUES ('"+dateString+"',"+a+");"
        println(sqlstring4)

             db.execSQL(sqlstring4)

        val date = Calendar.getInstance()
        date.time = Date() // устанавливаем текущую дату

        date.add(Calendar.MONTH, -1)
        val sqlstring5 = "INSERT OR IGNORE INTO measures (date,weight) VALUES ('"+dateFormatter.format(date.time)+"',"+a+");"


        db.execSQL(sqlstring5)


      //  val sqlstring4 = "INSERT OR IGNORE INTO users VALUES ('Tom Smithipp',"+a+"), ('John Dowipp', "+b+");"

     //   println(sqlstring4)
     //   db.execSQL(sqlstring4)

     //   print(sqlstring4)
        val sqlstring="INSERT OR IGNORE INTO users VALUES ('Tom Smithuoooo', 23), ('John Dowu', 31);"
       // db.execSQL("CREATE TABLE IF NOT EXISTS users (name TEXT, age INTEGER, UNIQUE(name))")
     //  db.execSQL("INSERT OR IGNORE INTO users VALUES ('Tom Smith', 23), ('John Dow', 31);")
     //   db.execSQL(sqlstring)

        val query = db.rawQuery("SELECT * FROM users;", null)
        val textView = findViewById<TextView>(R.id.textView)
        textView.text = ""



        while (query.moveToNext()) {
            val name = query.getString(0)
            val age = query.getInt(1)

            textView.append("Name: $name Age: $age\n")
        }

        val query2 = db.rawQuery("SELECT * FROM measures;", null)

        val dataPoints = ArrayList<DataPoint>()

        while (query2.moveToNext()) {
            val name = query2.getInt(0)
            val age = query2.getInt(2)
            dataPoints.add(DataPoint(name.toDouble(), age.toDouble()))
        }



       // query.close()
        //db.close()
    }
}