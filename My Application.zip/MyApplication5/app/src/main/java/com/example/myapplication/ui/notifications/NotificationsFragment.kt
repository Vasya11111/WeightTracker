package com.example.myapplication.ui.notifications





import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.Database
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentNotificationsBinding
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.helper.DateAsXAxisLabelFormatter
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.LineGraphSeries
import java.text.SimpleDateFormat
import java.util.*


/*class DatabaseHandler(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "app.db"
        private const val TABLE_NAME = "measures"
        private const val COLUMN_X = "date"
        private const val COLUMN_Y = "weight"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTable = "CREATE TABLE $TABLE_NAME ($COLUMN_X INTEGER, $COLUMN_Y INTEGER)"
        db?.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertData(x: Int, y: Int) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_X, x)
        values.put(COLUMN_Y, y)
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun getAllData(): ArrayList<DataPoint> {
        val dataPoints = ArrayList<DataPoint>()
        val selectQuery = "SELECT  * FROM $TABLE_NAME"
        val db = this.readableDatabase
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor.moveToFirst()) {
            do {
                val x = cursor.getInt(cursor.getColumnIndex(COLUMN_X)+3)
                val y = cursor.getInt(cursor.getColumnIndex(COLUMN_Y)+3)
                dataPoints.add(DataPoint(x.toDouble(), y.toDouble()))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return dataPoints
    }
}*/


/*
class Database  {

    fun f(context: Context?):ArrayList<DataPoint> {



        val db = context?.openOrCreateDatabase("app.db", AppCompatActivity.MODE_PRIVATE, null)


        db?.execSQL("DROP TABLE IF EXISTS measures")

        db?.execSQL("CREATE TABLE IF NOT EXISTS measures (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT UNIQUE, weight INTEGER)")

        val currentDate = Date()
        val dateFormatter = SimpleDateFormat("dd.MM.yyyy")
        val dateString = dateFormatter.format(currentDate)

        val sqlstring4 = "INSERT OR IGNORE INTO measures (date,weight) VALUES ('"+dateString+"',4);"
        println(sqlstring4)

        db?.execSQL(sqlstring4)

        val date = Calendar.getInstance()
        date.time = Date() // устанавливаем текущую дату

        date.add(Calendar.MONTH, -1)
        val sqlstring5 = "INSERT OR IGNORE INTO measures (date,weight) VALUES ('"+dateFormatter.format(date.time)+"',9);"


        db?.execSQL(sqlstring5)



        val query2 = db?.rawQuery("SELECT * FROM measures;", null)

        val dataPoints = ArrayList<DataPoint>()

        while (query2?.moveToNext()==true) {
            val name = query2.getInt(0)
            val age = query2.getInt(2)
            dataPoints.add(DataPoint(name.toDouble(), age.toDouble()))
        }

        return dataPoints



    }

}*/







class NotificationsFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null





    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!


    override fun onCreateView(
                inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

       // val lll = getView()?.findViewById<GraphView >(R.id.textView)




        val notificationsViewModel =
            ViewModelProvider(this).get(NotificationsViewModel::class.java)

        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textNotifications
        notificationsViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        return root
    }


    override fun onResume() {

       val db = context?.openOrCreateDatabase("app.db", AppCompatActivity.MODE_PRIVATE, null)



        val context: Context? = activity
       val datab= Database(db)
       val allpoints= datab.f(context)


        for (i in allpoints){
            println(i.x)
        }
        val series2 = LineGraphSeries<DataPoint>()
        for (i in 0 until allpoints.size) {

            series2.appendData(allpoints[i], true, 100)
        }




       // val databaseHandler = DatabaseHandler(context)
       // databaseHandler.insertData(2, 3)
      // databaseHandler.insertData(5, 8)
      //  databaseHandler.insertData(8, 12)


     //   val graphView = getView()?.findViewById<GraphView>(R.id.graph)
       // val series2 = LineGraphSeries(databaseHandler.getAllData().toTypedArray())
       // graphView?.addSeries(series2)



        super.onResume()

        val graph = getView()?.findViewById<GraphView >(R.id.graph)// as GraphView


        val series3 = LineGraphSeries(
            arrayOf(
                DataPoint(0.0, 1.0),
                DataPoint(1.0, 5.0),
                DataPoint(2.0, 3.0),
                DataPoint(3.0, 2.0),
                DataPoint(4.0, 6.0),
                DataPoint(5.0, 1.0),
                DataPoint(6.0, 5.0),
                DataPoint(7.0, 3.0),
                DataPoint(8.0, 2.0),
                DataPoint(9.0, 6.0),
                DataPoint(10.0, 1.0),
                DataPoint(11.0, 5.0),
                DataPoint(12.0, 3.0),
                DataPoint(13.0, 2.0),
                DataPoint(14.0, 6.0)
            )
        )

        graph?.addSeries(series2)
            //  graph?.addSeries(series3)
        // generate Dates
        // generate Dates
        val calendar: Calendar = Calendar.getInstance()
        val d1: Date = calendar.getTime()
        calendar.add(Calendar.DATE, 1)
        val d2: Date = calendar.getTime()
        calendar.add(Calendar.DATE, 1)
        val d3: Date = calendar.getTime()



// you can directly pass Date objects to DataPoint-Constructor
// this will convert the Date to double via Date#getTime()

// you can directly pass Date objects to DataPoint-Constructor
// this will convert the Date to double via Date#getTime()



      //  db.execSQL("CREATE TABLE IF NOT EXISTS measures (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT UNIQUE, weight INTEGER)")

        val series = LineGraphSeries(
          arrayOf<DataPoint>(
                DataPoint(d1, 1.0),
                DataPoint(d2, 5.0),
                DataPoint(d3, 3.0)
            )
        )

      //  graph?.addSeries(series)

// set date label formatter

// set date label formatter
      //  graph?.gridLabelRenderer?.labelFormatter = DateAsXAxisLabelFormatter(activity)
      //  graph?.gridLabelRenderer?.numHorizontalLabels = 3 // only 4 because of the space


// set manual x bounds to have nice steps

// set manual x bounds to have nice steps
       // graph?.viewport?.setMinX(d1.getTime().toDouble())
       // graph?.viewport?.setMaxX(d3.getTime().toDouble())
       // graph?.viewport?.isXAxisBoundsManual = true

       /* graph?.getViewport()?.setScalable(true); // enable scaling
        graph?.getViewport()?.setScrollable(true); // enable scrolling
        val series = LineGraphSeries(
            arrayOf(
                DataPoint(0.0, 1.0),
                DataPoint(1.0, 5.0),
                DataPoint(2.0, 3.0),
                DataPoint(3.0, 2.0),
                DataPoint(4.0, 6.0),
                DataPoint(5.0, 1.0),
                DataPoint(6.0, 5.0),
                DataPoint(7.0, 3.0),
                DataPoint(8.0, 2.0),
                DataPoint(9.0, 6.0),
                DataPoint(10.0, 1.0),
                DataPoint(11.0, 5.0),
                DataPoint(12.0, 3.0),
                DataPoint(13.0, 2.0),
                DataPoint(14.0, 6.0)
            )
        )
        graph?.addSeries(series)*/
        println(graph==null)
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}