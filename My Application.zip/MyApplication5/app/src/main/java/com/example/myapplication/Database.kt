package com.example.myapplication

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import com.jjoe64.graphview.series.DataPoint
import java.text.SimpleDateFormat
import java.util.*


class Database constructor(_db: SQLiteDatabase?)  {

    val db: SQLiteDatabase? = _db

    fun createDB (context: Context?,name:String){

        db?.execSQL("DROP TABLE IF EXISTS "+name)
        db?.execSQL("CREATE TABLE IF NOT EXISTS "+name+" (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT UNIQUE, weight INTEGER)")

    }

    fun insertData(currentDate: Calendar, y: Int) {
        val dateFormatter = SimpleDateFormat("dd.MM.yyyy")
        val dateString = dateFormatter.format(currentDate.time)

        val sqlstring4 = "INSERT OR IGNORE INTO measures (date,weight) VALUES ('"+dateString+"',"+y+");"
        println(sqlstring4)

        db?.execSQL(sqlstring4)
    }


    fun f(context: Context?): ArrayList<DataPoint> {

        createDB(context,"measures")


        val currentDate = Calendar.getInstance()
        currentDate.time = Date()
        insertData(currentDate, 4)


        val date = Calendar.getInstance()
        date.time = Date() // устанавливаем текущую дату
        date.add(Calendar.MONTH, -1)
        insertData(date, 9)




        val query2 = db?.rawQuery("SELECT * FROM measures;", null)

        val dataPoints = ArrayList<DataPoint>()

        while (query2?.moveToNext()==true) {
            val name = query2.getInt(0)
            val age = query2.getInt(2)
            dataPoints.add(DataPoint(name.toDouble(), age.toDouble()))
        }

        return dataPoints



    }

}